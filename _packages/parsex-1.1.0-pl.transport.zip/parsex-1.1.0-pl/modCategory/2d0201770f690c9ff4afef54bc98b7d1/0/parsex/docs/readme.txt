ParseX
======

Author: Guido Gallenkamp <guido.gallenkamp@posteo.de>
License: GNU GPLv2

ParseX is an extra for MODX to fetch XML files from any location on the web and put its contents into placeholders. It
works with rss feeds, product lists, race results or any nested XML format.

Usage
-----

[[!parsex? &source=`http://modx.com/feeds/latest.rss` &tpl=`xmlTpl` &element=`item` &wrapper=`wrapX`]]

In real words:

Please get that feed from modx.com and put all elements that are "item" into the microtemplate "parsexTpl". And please
also embed that mass of items into the microtemplate "parsexWrapTpl". Set &debugmode=`true` to see all available elements you can
use from your specific feed.

Documentation
-------------
https://github.com/Gallenkamp/ParseX/README.md

GitHub Repository
-----------------
https://github.com/Gallenkamp/ParseX