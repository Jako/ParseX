<?php
$_lang['parsex.parsex.source'] = 'Source URL for the XML feed';
$_lang['parsex.parsex.element'] = 'XML elements that should be collected for the output';
$_lang['parsex.parsex.tpl'] = 'Template for one element';
$_lang['parsex.parsex.wrapper'] = 'Wrapper template for all elements';
$_lang['parsex.parsex.outputSeparator'] = 'Optional string to separate each tpl instance';
$_lang['parsex.parsex.limit'] = 'Limits the number of elements returned (0 means no limit)';
$_lang['parsex.parsex.debugmode'] = 'If true output some debug informations after the normal output';
$_lang['parsex.parsex.cache'] = 'Amount of time (in seconds) the XML feed will be cached';
