<?php
$_lang['parsex'] = 'ParseX';
